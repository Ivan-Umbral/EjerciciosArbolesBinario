package ejercicio_13_11;

public class principal {

    public static void main(String[] args) {
    Object raiz[] = new Object[3];
    Arbol arbol = new Arbol(raiz);
    arbol.InsertarNodo(new nodo[3], 12);
    }
    
}
